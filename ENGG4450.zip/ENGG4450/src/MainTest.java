import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void testMultiplication() {
        // Test case 1: Regular inputs
        int result1 = Main.Multiplication(2, 3);
        assertEquals(6, result1);
    }

    @Test
    void testisPrime() {
        // Test case 1: Regular inputs
        boolean result1 = Main.isPrime(11);
        assertEquals(true, result1);
    }

}