public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world");
    }

    public static int Multiplication(int a, int b) {
        return (a*b);
    }

    public static boolean isPrime(int a) {
        if (a <= 1) {
            return false; // Numbers <= 1 are not prime
        }
        for (int i = 2; i <= Math.sqrt(a); i++) { // Check divisors up to √n
            if (a % i == 0) {
                return false;
            }
        }
        return true; // No divisors found, n is prime
    }
}
